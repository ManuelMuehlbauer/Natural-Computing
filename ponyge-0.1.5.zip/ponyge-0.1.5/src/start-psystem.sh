#!/bin/bash

./gui.py --grammar_type=PSystem --grammar_file=grammars/psystem.bnf
