#!/bin/bash

./gui.py --grammar_type=LSystem --grammar_file=grammars/lsystem.bnf
